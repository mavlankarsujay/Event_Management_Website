<?php
        include_once 'dbc/dbc.inc.php';

        $bname = $_POST['bname'];
        $gname = $_POST['gname'];
        $phone = $_POST['phone'];
        $inputguest = $_POST['inputguest'];
        $radio = $_POST['radio'];
        $total = $_POST['total'];

        $sql = "INSERT INTO weddingreg (bname, gname, phone, inputguest, radio, total)
                values ('$bname','$gname','$phone','$inputguest','$radio','$total');";


        mysqli_query($conn, $sql);

        header("Location: ../wedding.php?signup=success");
