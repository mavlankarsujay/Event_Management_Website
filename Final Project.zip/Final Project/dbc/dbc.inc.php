<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "typroject"

$conn = mysqli_connect($dbServername ,$dbUsername, $dbPassword, $dbName );

